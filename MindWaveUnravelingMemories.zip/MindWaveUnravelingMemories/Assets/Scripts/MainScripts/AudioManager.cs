using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AudioManager : MonoBehaviour
{
    public static AudioManager instance;

    public AudioClip menuMusic;
    public AudioClip gameMusic;

    private AudioSource audioSourceMainMusic;
    public AudioSource audioSourceSteps;
    public AudioSource audioSourceObstacles;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
            SceneManager.sceneLoaded += OnSceneLoaded;
            audioSourceMainMusic = GetComponent<AudioSource>();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name == "MainMenu") 
        {
            ChangeMusic(menuMusic);
        }
        else
        {
            ChangeMusic(gameMusic);
        }
    }

    public void ChangeMusic(AudioClip newClip)
    {
        if (audioSourceMainMusic.clip != newClip)
        {
            audioSourceMainMusic.Stop();
            audioSourceMainMusic.clip = newClip;
            audioSourceMainMusic.Play();
        }
    }
    public void PlayWalkingSound()
    {
        audioSourceSteps.Play();
    }
    public void PlayObstaclesSound()
    {
        audioSourceObstacles.Play();
    }
    public void StopSound(AudioSource audioSource)
    {
        audioSource.Stop();
    }
}
