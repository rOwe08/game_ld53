using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using System;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public float moveSpeed = 2f;
    public Vector3 targetPosition;
    public bool isMoving = false;
    public Animator animator;
    private SpriteRenderer spriteRenderer;
    public DialogController dialogController;

    public GameObject tilePrefab;

    public GameObject[,] gridOfTiles;
    public GameObject[,] obstacles;

    public AudioManager audioManager;
    public PlayerMovement PM;
    public Obstacles obs;

    public int playerSteps = 0;
    public int limitSteps;

    public int rows = 5;
    public int columns = 8;
    
    private void Start()
    {
        PM = GetComponent<PlayerMovement>();
        obs = GetComponent<Obstacles>();
        obstacles = new GameObject[rows, columns];

        audioManager = AudioManager.instance;
        gridOfTiles = new GameObject[rows, columns];
        int k = 0;

        for(int i = 0; i < rows; i++)
        {
            for (int j =  0; j < columns; j++)
            {
                gridOfTiles[i, j] = Tiles.Instance.tilesList[k];
                k++;
            }
        }

        obstacles = obs.CreateObstaclesArray(gridOfTiles);
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private bool IsNextCellFree(int row, int col)
    {
        return obstacles[row, col] == null;
    }

    public bool IsCloseEnough(int rowGoal, int colGoal, int rowLuna, int colLuna, RaycastHit2D hit)
    {
        int rowIndexDifference = Mathf.Abs(rowGoal - rowLuna);
        int columnIndexDifference = Mathf.Abs(colGoal - colLuna);

        if(hit.collider != null)
        {
            if ((rowIndexDifference == 1 && columnIndexDifference == 0) || (rowIndexDifference == 0 && columnIndexDifference == 1) || (colLuna == 7 && rowLuna == 2) && hit.collider.CompareTag("Goal"))
            {
                return true;
            }
        }
        return false;
    }

    void Update()
    {

        if (Input.GetMouseButtonDown(0) && !dialogController.introDialogPopup.activeInHierarchy && !dialogController.finalDialogPopup.activeInHierarchy && Time.timeScale != 0)
        {   
            RaycastHit2D hit = Physics2D.Raycast(Camera.main.ScreenToWorldPoint(Input.mousePosition), Vector2.zero);

            (int row, int col) = FindIndexesOfTile(hit);

            GetCurrentLunaRowAndColumn(out int currentLunaRow, out int currentLunaColumn);

            bool playerIsCloseEnough = IsCloseEnough(row, col, currentLunaRow, currentLunaColumn, hit);

            if (!playerIsCloseEnough)
            {
                return;
            }

            if (row != -1 && col != -1 && obstacles[row, col] != null)
            {
                if (limitSteps > playerSteps)
                {
                    PM.MoveObs(hit, row, col);
                }
                else
                {
                    dialogController.ShowLimitMessage();
                }
            }

            if (row != -1 && col != -1 && IsNextCellFree(row, col) || hit.collider.CompareTag("Goal"))
            {
                PM.MoveFree(hit, row, col, currentLunaRow, currentLunaColumn);
            }
        }

        if (isMoving)
        {
            MoveToTarget();
        }
    }

    public (int, int) FindIndexesOfTile(RaycastHit2D hit)
    {
        if (hit.collider != null)
        {
            GameObject clickedTile = hit.collider.gameObject;

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    if (gridOfTiles[i, j] == clickedTile || obstacles[i,j] == clickedTile)
                    {
                        return (i, j);
                    }
                }
            }
        }
        return (-1, -1);
    }

    void MoveToTarget()
    {
        float step = moveSpeed * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, step);

        if (transform.position.x < targetPosition.x)
        {
            spriteRenderer.flipX = false;
        }
        else if (transform.position.x > targetPosition.x)
        {
            spriteRenderer.flipX = true;
        }

        if (Vector3.Distance(transform.position, targetPosition) < 0.001f)
        {
            isMoving = false;
            animator.SetBool("IsMoving", false);
            audioManager.StopSound(audioManager.audioSourceSteps);
            audioManager.StopSound(audioManager.audioSourceObstacles);
        }
    }

    private void GetCurrentLunaRowAndColumn(out int currentLunaRow, out int currentLunaColumn)
    {
        currentLunaRow = -1;
        currentLunaColumn = -1;

        float minDistance = Mathf.Infinity;
        Vector3 characterPosition = transform.position;

        for (int row = 0; row < gridOfTiles.GetLength(0); row++)
        {
            for (int col = 0; col < gridOfTiles.GetLength(1); col++)
            {
                Vector3 tilePosition = gridOfTiles[row, col].transform.position;
                float distance = Vector3.Distance(characterPosition, tilePosition);

                if (distance < minDistance)
                {
                    minDistance = distance;
                    currentLunaRow = row;
                    currentLunaColumn = col;
                }
            }
        }
    }
}

