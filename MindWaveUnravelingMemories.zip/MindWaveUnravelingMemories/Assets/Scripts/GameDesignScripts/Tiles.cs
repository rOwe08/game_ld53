using System.Collections.Generic;
using UnityEngine;

public class Tiles : MonoBehaviour
{
    public static Tiles Instance { get; private set; }

    public List<GameObject> tilesList;
    public GameObject tilePrefab;
    public float tileSizeX;

    void Awake()
    {
        tilesList = GetOrderedTiles();
        if (Instance == null)
        {
            Instance = this;
            this.tileSizeX = tilePrefab.GetComponent<BoxCollider2D>().bounds.size.x;
            DontDestroy.dontDestroyObjects.Add(gameObject);
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public List<GameObject> GetOrderedTiles()
    {
        GameObject[] tilesArray = GameObject.FindGameObjectsWithTag("WalkableField");
        List<GameObject> unorderedTiles = new List<GameObject>(tilesArray);

        unorderedTiles.Sort((tile1, tile2) =>
        {
            if (tile1.transform.position.y != tile2.transform.position.y)
                return tile2.transform.position.y.CompareTo(tile1.transform.position.y); 
            else
                return tile1.transform.position.x.CompareTo(tile2.transform.position.x);  
        });

        return unorderedTiles;
    }

}