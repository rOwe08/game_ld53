using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.Rendering.DebugUI.Table;

public class Obstacles : MonoBehaviour
{
    private GameObject[,] obstacles;
    private int rows = 5;
    private int columns = 8;

    public GameObject[,] CreateObstaclesArray(GameObject[,] gridOfTiles)
    {
        GameObject[] pushableObjects = GameObject.FindGameObjectsWithTag("Pushable");
        Dictionary<Vector2Int, GameObject> obstaclePositions = new Dictionary<Vector2Int, GameObject>();

        foreach (GameObject pushableObject in pushableObjects)
        {
            float minDistance = float.MaxValue;
            Vector2Int closestTileIndex = new Vector2Int(-1, -1);

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    float distance = Vector3.Distance(pushableObject.transform.position, gridOfTiles[i, j].transform.position);
                    if (distance < minDistance)
                    {
                        minDistance = distance;
                        closestTileIndex = new Vector2Int(i, j);
                    }
                }
            }

            if (closestTileIndex.x != -1 && closestTileIndex.y != -1)
            {
                obstaclePositions.Add(closestTileIndex, pushableObject);
            }
        }

        obstacles = new GameObject[rows, columns];

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                Vector2Int currentTileIndex = new Vector2Int(i, j);
                if (obstaclePositions.ContainsKey(currentTileIndex))
                {
                    obstacles[i, j] = obstaclePositions[currentTileIndex];
                }
            }
        }
        return obstacles;
    }
}
