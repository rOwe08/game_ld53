using Newtonsoft.Json.Bson;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ButtonLocalization : MonoBehaviour
{
    void Start()
    {
        DataCollector.Instance.IncreaseIndexOfButton();
    }
    public void UpdateLocalization()
    {
        TextMeshProUGUI textComponent = this.gameObject.GetComponent<Button>().GetComponentInChildren<TextMeshProUGUI>();
        if (textComponent != null)
        {
            textComponent.font = DataCollector.Instance.mainFontButton;
            textComponent.text = DataCollector.Instance.buttonsText[DataCollector.Instance.indexOfButton];
        }
    }
    private void Update()
    {
        UpdateLocalization();
    }
}
