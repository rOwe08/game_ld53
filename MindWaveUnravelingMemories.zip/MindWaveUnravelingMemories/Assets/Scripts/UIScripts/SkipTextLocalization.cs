﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;

public class SkipTextLocalization : MonoBehaviour
{
    private TextMeshProUGUI skipText;
    void Start()
    {
        skipText = GetComponent<TextMeshProUGUI>();

        if (DataCollector.Instance.language == DataCollector.Language.EN)
        {
            skipText.text = $"\"Space\" to skip";
        }
        else if (DataCollector.Instance.language == DataCollector.Language.CZ)
        {
            skipText.text = $"\"Space\" přeskočit";
        }
    }
}
