using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PauseMenuController : MonoBehaviour
{
    private bool isPaused = false;
    private GameObject menu;
    private GameObject ExitGameButton, MainMenuButton, RestartLevelButton;

    private void Start()
    {
        menu = GameManager.Instance.FindInactiveObjectByTag("PauseMenu");

        ExitGameButton = GameManager.Instance.FindInactiveObjectByTag("ExitButton");
        MainMenuButton = GameManager.Instance.FindInactiveObjectByTag("MainMenuButton");
        RestartLevelButton = GameManager.Instance.FindInactiveObjectByTag("RestartButton");

        ExitGameButton.GetComponent<Button>().onClick.AddListener(ExitGame);
        RestartLevelButton.GetComponent<Button>().onClick.AddListener(RestartLevel);
        MainMenuButton.GetComponent<Button>().onClick.AddListener(BackToMainMenu);
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePauseMenu();
        }
    }

    public void TogglePauseMenu()
    {
        isPaused = !isPaused;
        menu.SetActive(isPaused);

        if (isPaused)
        {
            Time.timeScale = 0f;
        }
        else
        {
            Time.timeScale = 1f;
        }
    }

    public void RestartLevel()
    {
        DataCollector.Instance.ResetIndexes();
        GameManager.Instance.LoadSceneByIndex(SceneManager.GetActiveScene().buildIndex);
        Time.timeScale = 1f;
    }

    public void BackToMainMenu()
    {
        CleanerDontDestroy.Cleanup();
        GameManager.Instance.LoadSceneByIndex(0);
        Time.timeScale = 1f;
    }
    public void ExitGame()
    {
        Application.Quit();
    }
}
