﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    private Player player;
    private Text scoreText;

    private Font mainFontText;
    private Font fontDialogEN;
    private Font fontDialogCZ;

    void Awake()
    {
        fontDialogCZ = DataCollector.Instance.fontDialogCZ;
        fontDialogEN = DataCollector.Instance.fontDialogEN;
        scoreText = GetComponent<Text>();
        player = FindObjectOfType<Player>();
    }

    public void UpdateScoreText()
    {
        if(DataCollector.Instance.language == DataCollector.Language.EN)
        {
            mainFontText = fontDialogEN;
            scoreText.text = $"limit of movement of obstacles: {player.limitSteps}\nyour count of movements: {player.playerSteps}";
        }
        else if (DataCollector.Instance.language == DataCollector.Language.CZ)
        {
            mainFontText = fontDialogCZ;
            scoreText.text = $"Omezení pohybu překážek: {player.limitSteps}\nVáš počet pohybů: {player.playerSteps}";
        }
        scoreText.font = mainFontText;
    }
}
