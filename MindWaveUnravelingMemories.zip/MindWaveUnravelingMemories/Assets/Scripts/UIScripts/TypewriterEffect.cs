using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TypewriterEffect : MonoBehaviour
{
    public float delay = 0.01f;
    private string fullText;
    private string currentText = "";
    private int index;
    void Start()
    {
        DataCollector.Instance.IncreaseIndexOfDialog();
        fullText = DataCollector.Instance.dialogsText[DataCollector.Instance.indexOfDialog];

        index = FindIndexFirstWord();
        StartCoroutine(ShowText());

        this.GetComponent<Text>().font = DataCollector.Instance.mainFontDialog;
    }
    IEnumerator ShowText()
    {
        if(DataCollector.Instance.indexOfDialog < DataCollector.Instance.dialogsText.Count - 1)
        {
            for (int i = index; i < fullText.Length + 1; i++)
            {
                if (Input.GetKeyUp(KeyCode.Space))
                {
                    currentText = fullText;
                    this.GetComponent<Text>().text = currentText;
                    break;
                }
                currentText = fullText.Substring(0, i);
                this.GetComponent<Text>().text = currentText;

                yield return new WaitForSeconds(delay);
            }
        }
        else
        {
            currentText = fullText;
            this.GetComponent<Text>().text = currentText;
        }
    }

    private int FindIndexFirstWord() => fullText.Split(' ')[0].Length - 1;
}