using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;

public class DataCollector : MonoBehaviour
{
    public static DataCollector Instance { get; private set; }

    public int indexOfDialog = -1;
    public int indexOfButton = -1;
    public int indexDialogStartScene = -1;
    public int indexButtonStartScene = -1;

    public List<string> dialogsText;
    public List<string> buttonsText;

    private string fileDialogNameEN = "Data/dialogsEN";
    private string fileDialogNameCZ = "Data/dialogsCZ";
    private string fileButtonNameEN = "Data/buttonEN";
    private string fileButtonNameCZ = "Data/buttonCZ";

    public Font mainFontDialog;
    public Font fontDialogEN;
    public Font fontDialogCZ;

    public TMP_FontAsset mainFontButton;
    public TMP_FontAsset fontButtonEN;
    public TMP_FontAsset fontButtonCZ;

    public Language language;
    public enum Language
    {
        EN,
        CZ
    }
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        ChangeToEN();
        DontDestroyOnLoad(gameObject);
    }

    public void ResetFull()
    {
        indexOfDialog = -1;
        indexOfButton = -1;
        indexDialogStartScene = -1;
        indexButtonStartScene = -1;
    }
    public void IncreaseIndexOfDialog()
    {
        indexOfDialog++;
    }
    public void IncreaseIndexOfButton()
    {
        indexOfButton++;
    }
    public void ResetIndexes()
    {
        indexOfDialog = indexDialogStartScene;
        indexOfButton = indexButtonStartScene;
    }
    public void SetIndex()
    {
        indexDialogStartScene = indexOfDialog;
        indexButtonStartScene = indexOfButton;
    }
    private void GetDialogs(string fileNameDialogs)
    {
        TextAsset textAsset = Resources.Load<TextAsset>(fileNameDialogs);
        if (textAsset != null)
        {
            string[] lines = textAsset.text.Split('\n');
            this.dialogsText = new List<string>(lines);
        }
        else
        {
            Debug.LogError("Could not load text asset: " + fileNameDialogs);
        }
    }

    private void GetButtons(string fileName)
    {
        TextAsset textAsset = Resources.Load<TextAsset>(fileName);
        if (textAsset != null)
        {
            string[] lines = textAsset.text.Split('\n');
            this.buttonsText = new List<string>(lines);
        }
        else
        {
            Debug.LogError("Could not load text asset: " + fileName);
        }
    }

    public void ChangeToEN()
    {
        language = Language.EN;
        mainFontDialog = fontDialogEN;
        mainFontButton = fontButtonEN;
        GetDialogs(fileDialogNameEN);
        GetButtons(fileButtonNameEN);
    }
    public void ChangeToCZ()
    {
        language = Language.CZ;
        mainFontDialog = fontDialogCZ;
        mainFontButton = fontButtonCZ;
        GetDialogs(fileDialogNameCZ);
        GetButtons(fileButtonNameCZ);
    }
}

