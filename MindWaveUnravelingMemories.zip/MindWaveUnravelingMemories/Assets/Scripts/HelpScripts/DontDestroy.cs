using System.Collections.Generic;
using UnityEngine;

public class DontDestroy : MonoBehaviour
{
    private static DontDestroy instance;
    public static List<GameObject> dontDestroyObjects = new List<GameObject>();
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            dontDestroyObjects.Add(gameObject);
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            if (instance != this)
            {
                Destroy(gameObject);
            }
        }
    }
}
