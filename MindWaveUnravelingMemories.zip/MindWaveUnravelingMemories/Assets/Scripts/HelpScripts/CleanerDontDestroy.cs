using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CleanerDontDestroy : MonoBehaviour
{
    public static void Cleanup()
    {
        foreach (var obj in DontDestroy.dontDestroyObjects)
        {
            Destroy(obj);
        }
        DontDestroy.dontDestroyObjects.Clear();
    }
}
