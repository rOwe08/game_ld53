using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class VolumeController : MonoBehaviour
{
    public Slider volumeSlider;
    private List<AudioSource> audioSources;
    public AudioSource stepsSound;

    private void Start()
    {
        audioSources = new List<AudioSource>(AudioManager.instance.gameObject.GetComponents<AudioSource>());
        volumeSlider.value = audioSources[0].volume;
    }

    public void ChangeVolume()
    {
        foreach (AudioSource source in audioSources)
        {
            source.volume = volumeSlider.value;
        }

        if(stepsSound != null)
        {
            stepsSound.volume = volumeSlider.value;
        }
    }
    public void ActivateSlider()
    {
        volumeSlider.gameObject.SetActive(!volumeSlider.gameObject.activeSelf);
    }
}
