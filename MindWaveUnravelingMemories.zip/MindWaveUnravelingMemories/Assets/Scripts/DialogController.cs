﻿using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class DialogController : MonoBehaviour
{
    public GameObject introDialogPopup;
    public Button introCloseButton;

    public GameObject finalDialogPopup;
    public Button finalCloseButton;
    
    public GameObject limitMessage;

    public bool isClosed = false;
    void Awake()
    {
        introCloseButton.onClick.AddListener(CloseIntroDialog);
        finalCloseButton.onClick.AddListener(CloseFinalDialog);
    }

    public void ShowFinalDialog()
    {
        finalDialogPopup.SetActive(true);
    }
    public void CloseIntroDialog()
    {
        introDialogPopup.SetActive(false);
        isClosed = true;
    }
    public void ShowWindow(GameObject window)
    {
        window.SetActive(true);
    }
    public void CloseFinalDialog()
    {
        finalDialogPopup.SetActive(false);
        Scene currentScene = SceneManager.GetActiveScene();

        if(currentScene.buildIndex < 7)
        {
            GameManager.Instance.LoadSceneByIndex(currentScene.buildIndex + 1);
        }
    }
    public void CloseEpilogueDialog()
    {
        CleanerDontDestroy.Cleanup();
        GameManager.Instance.LoadSceneByIndex(0);
    }
    public void ShowLimitMessage()
    {
        TextMeshProUGUI limitText = limitMessage.GetComponentInChildren<TextMeshProUGUI>();

        if (DataCollector.Instance.language == DataCollector.Language.EN)
        {
            limitText.font = DataCollector.Instance.fontButtonEN;
            limitText.text = $"Your limit is over!\r\nrestart the level";
        }
        else if (DataCollector.Instance.language == DataCollector.Language.CZ)
        {
            limitText.font = DataCollector.Instance.fontButtonCZ;
            limitText.text = $"Váš limit je u konce!\r\nRestartujte úroveň";
        }

        StartCoroutine(ShowAndHide(limitMessage, 2.0f));
    }

    IEnumerator ShowAndHide(GameObject gameObject, float delay)
    {
        gameObject.SetActive(true);
        yield return new WaitForSeconds(delay);
        gameObject.SetActive(false);
    }
}

