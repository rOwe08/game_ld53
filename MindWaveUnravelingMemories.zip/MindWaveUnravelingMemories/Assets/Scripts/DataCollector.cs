using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using static Unity.VisualScripting.Icons;

public class DataCollector : MonoBehaviour
{
    public static DataCollector Instance { get; private set; }

    public int indexOfDialog = -1;
    public int indexOfButton = -1;
    public int indexDialogStartScene = -1;
    public int indexButtonStartScene = -1;

    public List<string> dialogsText;
    public List<string> buttonsText;

    private string fileDialogNameEN = "dialogsEN.txt";
    private string fileDialogNameCZ = "dialogsCZ.txt";
    private string fileButtonNameEN = "buttonEN.txt";
    private string fileButtonNameCZ = "buttonCZ.txt";

    public Font mainFontDialog;
    public Font fontDialogEN;
    public Font fontDialogCZ;

    public TMP_FontAsset mainFontButton;
    public TMP_FontAsset fontButtonEN;
    public TMP_FontAsset fontButtonCZ;

    public Language language;
    public enum Language
    {
        EN,
        CZ
    }
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        ChangeToEN();
        DontDestroyOnLoad(gameObject);
    }

    public void ResetFull()
    {
        indexOfDialog = -1;
        indexOfButton = -1;
        indexDialogStartScene = -1;
        indexButtonStartScene = -1;
    }
    public void IncreaseIndexOfDialog()
    {
        indexOfDialog++;
    }
    public void IncreaseIndexOfButton()
    {
        indexOfButton++;
    }
    public void ResetIndexes()
    {
        indexOfDialog = indexDialogStartScene;
        indexOfButton = indexButtonStartScene;
    }
    public void SetIndex()
    {
        indexDialogStartScene = indexOfDialog;
        indexButtonStartScene = indexOfButton;
    }
    private void GetDialogs(string fileNameDialogs)
    {
        List<string> dialogsTemp = new List<string>();
        string line;

        using (StreamReader sr = new StreamReader(fileNameDialogs))
        {
            while ((line = sr.ReadLine()) != null)
            {
                dialogsTemp.Add(line);
            }
        }
        this.dialogsText = dialogsTemp;
    }
    private void GetButtons(string fileName)
    {
        List<string> buttonsTemp = new List<string>();
        string line;

        using (StreamReader sr = new StreamReader(fileName))
        {
            while ((line = sr.ReadLine()) != null)
            {
                buttonsTemp.Add(line);
            }
        }
        this.buttonsText = buttonsTemp;
    }
    public void ChangeToEN()
    {
        language = Language.EN;
        mainFontDialog = fontDialogEN;
        mainFontButton = fontButtonEN;
        GetDialogs(fileDialogNameEN);
        GetButtons(fileButtonNameEN);
    }
    public void ChangeToCZ()
    {
        language = Language.CZ;
        mainFontDialog = fontDialogCZ;
        mainFontButton = fontButtonCZ;
        GetDialogs(fileDialogNameCZ);
        GetButtons(fileButtonNameCZ);
    }
}

