using UnityEngine;

public class PushableObject : MonoBehaviour
{
    public float moveSpeed = 2f;
    private Vector3 targetPosition;
    public bool isMoving = false;
    private BoxCollider2D boxCollider;

    private void Start()
    {
        boxCollider = GetComponent<BoxCollider2D>();
    }

    void Update()
    {
        if (isMoving)
        {
            MoveToTarget();
        }
    }

    public void SetTargetPosition(Vector3 newTargetPosition)
    {
        targetPosition = newTargetPosition;
        isMoving = true;
    }

    void MoveToTarget()
    {
        float step = moveSpeed * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, step);

        if (Vector3.Distance(transform.position, targetPosition) < 0.001f)
        {
            isMoving = false;
        }
    }

    public Vector3 FindNextPosObs(Vector3 direction, float tileSize)
    {
        Vector3 newPosition;

        // Determine the primary axis of movement
        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
        {
            // Move horizontally
            newPosition = transform.position + new Vector3(Mathf.Sign(direction.x) * tileSize, 0, 0);
        }
        else
        {
            // Move vertically
            newPosition = transform.position + new Vector3(0, Mathf.Sign(direction.y) * tileSize, 0);
        }

        return newPosition;
    }


}
