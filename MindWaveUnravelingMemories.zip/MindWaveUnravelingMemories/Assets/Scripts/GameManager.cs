using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public void LoadSceneByIndex(int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex);
        if (sceneIndex == 0)
        {
            DataCollector.Instance.ResetFull();
        }
        DataCollector.Instance.SetIndex();
    }
    public GameObject FindInactiveObjectByTag(string tag)
    {
        GameObject[] gos = (GameObject[])Resources.FindObjectsOfTypeAll(typeof(GameObject));

        for (int i = 0; i < gos.Length; i++)
        {
            if (gos[i].hideFlags == HideFlags.NotEditable || gos[i].hideFlags == HideFlags.HideAndDontSave)
                continue;

            if (gos[i].tag == tag)
                return gos[i];
        }

        return null;
    }
}
