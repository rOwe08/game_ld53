using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.Burst.CompilerServices;
using UnityEngine;
using UnityEngine.SceneManagement;
using static UnityEngine.Rendering.DebugUI.Table;

public class PlayerMovement : MonoBehaviour
{
    private GameObject[,] obstacles;
    private int rows = 5;
    private int columns = 8;
    private Player player;
    private ScoreManager scoreManager;

    private void Start()
    {
        player = GetComponent<Player>();
        scoreManager = FindObjectOfType<ScoreManager>();
        if(scoreManager != null)
        {
            scoreManager.UpdateScoreText();
        }
        obstacles = player.obstacles;
    }
    public void MoveObs(RaycastHit2D hit, int row, int col)
    {
        Vector3 pushDirection = (hit.collider.transform.position - transform.position).normalized;

        PushableObject pushableObject = obstacles[row, col].GetComponent<PushableObject>();

        // Push the pushable object in the direction of player movement
        Vector3 nextObsCell = pushableObject.FindNextPosObs(pushDirection, Tiles.Instance.tileSizeX);
        FindClosestTile(nextObsCell, out int nextRow, out int nextColumn);
        player.audioManager.PlayObstaclesSound();

        if (nextRow > -1 && nextColumn > -1 && nextRow <= rows && nextColumn <= columns && IsNextCellFree(nextRow, nextColumn))
        {
            pushableObject.SetTargetPosition(nextObsCell);
            obstacles[nextRow, nextColumn] = obstacles[row, col];
            obstacles[row, col] = null;
            player.playerSteps++;
            if (scoreManager != null)
            {
                scoreManager.UpdateScoreText();
            }
        }
        else
        {
            player.audioManager.StopSound(player.audioManager.audioSourceObstacles);
            return;
        }
    }
    public void MoveFree(RaycastHit2D hit, int row, int col, int currentLunaRow, int currentLunaColumn)
    {
        // Check if the movement is vertical or horizontal only
        int rowIndexDifference = Mathf.Abs(row - currentLunaRow);
        int columnIndexDifference = Mathf.Abs(col - currentLunaColumn);

        // We allow movement only if the cell is adjacent horizontally or vertically
        if ((rowIndexDifference == 1 && columnIndexDifference == 0) || (rowIndexDifference == 0 && columnIndexDifference == 1))
        {
            Vector3 targetTilePosition = player.gridOfTiles[row, col].transform.position;

            PlayMoving(hit, targetTilePosition);
        }

        if (hit.collider.CompareTag("Goal"))
        {
            Vector3 targetTilePosition = hit.collider.gameObject.transform.position;

            PlayMoving(hit, targetTilePosition);

            player.dialogController.ShowFinalDialog();
        }
    }
    private void PlayMoving(RaycastHit2D hit, Vector3 targetTilePosition)
    {
        Vector3 tileSize = hit.collider.bounds.size;
        Vector3 characterSize = GetComponent<CapsuleCollider2D>().bounds.size;

        Vector3 adjustedPosition = new Vector3(
            targetTilePosition.x,
            targetTilePosition.y + tileSize.y / 2 + characterSize.y / 2 - 0.2f,
            targetTilePosition.z
        );

        player.targetPosition = adjustedPosition;
        player.isMoving = true;
        player.animator.SetBool("IsMoving", true);
        player.audioManager.PlayWalkingSound();
    }
    public void FindClosestTile(Vector3 positionNextCell, out int nextRow, out int nextColumn)
    {
        nextRow = -1;
        nextColumn = -1;

        float minDistance = Mathf.Infinity;

        for (int row = 0; row < player.gridOfTiles.GetLength(0); row++)
        {
            for (int col = 0; col < player.gridOfTiles.GetLength(1); col++)
            {
                Vector3 tilePosition = player.gridOfTiles[row, col].transform.position;
                float distance = Vector3.Distance(positionNextCell, tilePosition);

                if (distance < minDistance)
                {
                    minDistance = distance;
                    nextRow = row;
                    nextColumn = col;
                }
            }
        }
    }
    private bool IsNextCellFree(int row, int col)
    {
        return obstacles[row, col] == null;
    }

}
